<!-- DO NOT EDIT MANUALLY, THIS FILE HAS BEEN GENERATED -->

# @xen-orchestra/mixins

[![Package Version](https://badgen.net/npm/v/@xen-orchestra/mixins)](https://npmjs.org/package/@xen-orchestra/mixins) ![License](https://badgen.net/npm/license/@xen-orchestra/mixins) [![PackagePhobia](https://badgen.net/bundlephobia/minzip/@xen-orchestra/mixins)](https://bundlephobia.com/result?p=@xen-orchestra/mixins) [![Node compatibility](https://badgen.net/npm/node/@xen-orchestra/mixins)](https://npmjs.org/package/@xen-orchestra/mixins)

> Mixins shared between xo-proxy and xo-server

## Install

Installation of the [npm package](https://npmjs.org/package/@xen-orchestra/mixins):

```sh
npm install --save @xen-orchestra/mixins
```

## Contributions

Contributions are _very_ welcomed, either on the documentation or on
the code.

You may:

- report any [issue](https://github.com/vatesfr/xen-orchestra/issues)
  you've encountered;
- fork and create a pull request.

## License

[AGPL-3.0-or-later](https://spdx.org/licenses/AGPL-3.0-or-later) © [Vates SAS](https://vates.fr)
