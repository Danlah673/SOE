'use strict'

module.exports = require('../../@xen-orchestra/babel-config')(require('./package.json'))
