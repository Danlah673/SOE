<!-- DO NOT EDIT MANUALLY, THIS FILE HAS BEEN GENERATED -->

# @xen-orchestra/fs

[![Package Version](https://badgen.net/npm/v/@xen-orchestra/fs)](https://npmjs.org/package/@xen-orchestra/fs) ![License](https://badgen.net/npm/license/@xen-orchestra/fs) [![PackagePhobia](https://badgen.net/bundlephobia/minzip/@xen-orchestra/fs)](https://bundlephobia.com/result?p=@xen-orchestra/fs) [![Node compatibility](https://badgen.net/npm/node/@xen-orchestra/fs)](https://npmjs.org/package/@xen-orchestra/fs)

> The File System for Xen Orchestra backups.

## Install

Installation of the [npm package](https://npmjs.org/package/@xen-orchestra/fs):

```sh
npm install --global @xen-orchestra/fs
```

## Contributions

Contributions are _very_ welcomed, either on the documentation or on
the code.

You may:

- report any [issue](https://github.com/vatesfr/xen-orchestra/issues)
  you've encountered;
- fork and create a pull request.

## License

[AGPL-3.0-or-later](https://spdx.org/licenses/AGPL-3.0-or-later) © [Vates SAS](https://vates.fr)
