export default {
  size: 8,
  offsets: {
    version: 0,
    type: 1,
    length: 2,
    xid: 4,
  },
}
