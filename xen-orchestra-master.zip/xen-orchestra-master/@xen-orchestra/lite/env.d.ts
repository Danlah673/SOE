/// <reference types="vite/client" />
/// <reference types="json-rpc-2.0/dist" />
/// <reference types="vite-plugin-pages/client" />

declare const XO_LITE_VERSION: string;
declare const XO_LITE_GIT_HEAD: string;
