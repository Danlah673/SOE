// Keeping this file to prevent applying the global monorepo config for now
module.exports = {};
