module.exports = {
  plugins: {
    "postcss-nested": {},
    "postcss-custom-media": {},
  },
};
