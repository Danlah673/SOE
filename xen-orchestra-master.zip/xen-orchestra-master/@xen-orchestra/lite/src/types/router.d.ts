declare module "vue-router" {
  interface RouteMeta {
    hasStoryNav?: boolean;
    isStory?: boolean;
    storyTitle?: string;
    storyMdPath?: string;
  }
}
export {};
