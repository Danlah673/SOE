export type LinearChartData = {
  label: string;
  data: {
    timestamp: number;
    value: number;
  }[];
}[];
