declare module "decorator-synchronized" {
  export const synchronized: any;
}
