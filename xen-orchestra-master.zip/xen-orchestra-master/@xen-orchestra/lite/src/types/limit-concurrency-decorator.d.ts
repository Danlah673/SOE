declare module "limit-concurrency-decorator" {
  export const limitConcurrency: any;
}
