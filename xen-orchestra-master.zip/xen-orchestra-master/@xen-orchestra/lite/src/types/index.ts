export type Color = "info" | "error" | "warning" | "success";
