```vue-template
<ProgressCircle
  :value="value"
  :max-value="maxValue"
/>
```
