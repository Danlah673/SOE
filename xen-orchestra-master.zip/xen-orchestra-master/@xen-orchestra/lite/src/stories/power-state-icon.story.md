```vue-template
<PowerStateIcon :state="powerState" />
```
