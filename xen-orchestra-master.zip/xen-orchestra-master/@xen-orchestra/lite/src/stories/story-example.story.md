# Documentation for Story Example

This is a story example.

The source file is located in `src/stories/story-example.story.vue`.

The content you are reading right now is written in Markdown in the `src/stories/story-example.story.md` file.
