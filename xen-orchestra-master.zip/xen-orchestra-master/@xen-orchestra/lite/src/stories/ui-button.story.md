Here is some doc for UiButton component

```vue-template
<UiButton @click="doSomething">Click me</UiButton>
```
