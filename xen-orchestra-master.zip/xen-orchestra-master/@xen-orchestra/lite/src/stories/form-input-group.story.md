```vue-template
<FormInputGroup>
  <FormInput />
  <FormInput />
  <FormSelect>
    <option>Option 1</option>
    <option>Option 2</option>
    <option>Option 3</option>
  </FormSelect>
</FormInputGroup>
```
