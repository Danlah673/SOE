<template>
  <hr class="ui-separator" />
</template>

<style lang="postcss" scoped>
.ui-separator {
  border: none;
  border-top: 1px solid var(--color-blue-scale-400);
  margin: 2rem 0;
}
</style>
