<template>
  <table class="ui-key-value-list">
    <tbody>
      <slot />
    </tbody>
  </table>
</template>

<script lang="ts" setup></script>

<style lang="postcss" scoped>
.ui-key-value-list {
  border-spacing: 0;
}
</style>
