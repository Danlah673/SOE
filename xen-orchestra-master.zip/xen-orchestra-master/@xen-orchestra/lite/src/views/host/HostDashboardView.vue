<template>
  <PageUnderConstruction />
</template>

<script lang="ts" setup>
import PageUnderConstruction from "@/components/PageUnderConstruction.vue";
</script>
